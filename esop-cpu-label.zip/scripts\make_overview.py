# -*- coding: utf-8 -*-
"""
把一批 ESOP 核对图拼成一张总览，方便现场一次看全、也方便贴进作业指导书。

用法:
    python make_overview.py 目录 -o 00_总览.png [--cols 4]

每格下方标出文件名，按文件名排序。单张超过 560 px 宽会自动缩小。
"""
import os, sys, glob, argparse
from PIL import Image, ImageDraw, ImageFont


def _font_path():
    for c in [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc",
              r"C:\Windows\Fonts\simhei.ttf",
              "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
              "/System/Library/Fonts/PingFang.ttc"]:
        if os.path.exists(c):
            return c
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("indir")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--cell", type=int, default=560)
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.indir, "*.png")))
    files = [f for f in files if not os.path.basename(f).startswith("00_")
             and "_anchor" not in f and "_crops" not in f]
    if not files:
        print("目录里没有 png")
        return
    out = a.out or os.path.join(a.indir, "00_总览.png")

    fx = _font_path()
    fs = ImageFont.truetype(fx, 20) if fx else ImageFont.load_default()

    cell = a.cell
    lab_h = 34
    rows = (len(files) + a.cols - 1) // a.cols
    W, H = a.cols * (cell + 16) + 16, rows * (cell + lab_h + 16) + 16
    canvas = Image.new("RGB", (W, H), (245, 245, 245))
    dr = ImageDraw.Draw(canvas)

    for i, f in enumerate(files):
        im = Image.open(f).convert("RGB")
        k = min(1.0, (cell - 8) / im.width, (cell - 8) / im.height)
        if k < 1:
            im = im.resize((int(im.width * k), int(im.height * k)), Image.LANCZOS)
        c, r = i % a.cols, i // a.cols
        x = 16 + c * (cell + 16)
        y = 16 + r * (cell + lab_h + 16)
        canvas.paste(im, (x, y + lab_h))
        dr.text((x, y + 6), os.path.splitext(os.path.basename(f))[0][:40], font=fs, fill=(40, 40, 40))

    canvas.save(out)
    print("OVERVIEW", out, canvas.size, len(files), "张")


if __name__ == "__main__":
    main()
