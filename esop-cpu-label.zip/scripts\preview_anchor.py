﻿# -*- coding: utf-8 -*-
"""
锚点自检：在标签原图上直接叠加所有标注框，肉眼确认框里到底有没有那行字。

渲染前必跑。CPU 标签上常见的坑是：语义上有 "7000"，但标签上真实印的 7000
在底部 SERIES 条里，而 AMD RYZEN 大字区并没有这个字——不先看图就写 box，框一定落错。

用法:
    python preview_anchor.py spec.json [--outdir 目录] [--only 关键字]
输出 <标签名>_anchor.png，每个框上方标出它对应的标注文本，底部列出坐标清单。
"""
import os, sys, json, math, argparse
from PIL import Image, ImageDraw, ImageFont

RED = (255, 0, 0)
GREEN = (0, 176, 80)
YELLOW = (255, 235, 0)


def _font_path():
    for c in [r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc",
              r"C:\Windows\Fonts\simhei.ttf",
              "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
              "/System/Library/Fonts/PingFang.ttc"]:
        if os.path.exists(c):
            return c
    return None


def arrow(dr, start, end, width=6, head=20):
    dx, dy = end[0] - start[0], end[1] - start[1]
    L = math.hypot(dx, dy)
    if L < 2:
        return
    ux, uy = dx / L, dy / L
    base = (end[0] - ux * head, end[1] - uy * head)
    dr.line([start, base], fill=GREEN, width=width)
    px, py = -uy, ux
    hw = head * 0.45
    dr.polygon([end, (base[0] + px * hw, base[1] + py * hw), (base[0] - px * hw, base[1] - py * hw)], fill=GREEN)


def preview(spec, out_path, scale_min=900):
    im = Image.open(spec["label"]).convert("RGB")
    k = max(1.0, scale_min / im.width)
    im = im.resize((int(im.width * k), int(im.height * k)), Image.LANCZOS)
    W, H = im.size

    fx = _font_path()
    f = ImageFont.truetype(fx, max(18, int(W * 0.035))) if fx else ImageFont.load_default()
    fsmall = ImageFont.truetype(fx, max(14, int(W * 0.022))) if fx else f

    # 每个框的裁切放大，作为"框里到底是什么字"的证据
    cells = []
    for sm in spec.get("smalls") or []:
        x1, y1, x2, y2 = sm["box"]
        c = im.crop((int(x1 * W), int(y1 * H), int(x2 * W), int(y2 * H)))
        if c.width < 2 or c.height < 2:
            continue
        kk = min(4.0, 130.0 / c.height)
        cells.append((sm["text"], c.resize((max(1, int(c.width * kk)), max(1, int(c.height * kk))), Image.LANCZOS)))
    crops_h = sum(c.height + 34 for _, c in cells) + 60 if cells else 0

    top_pad = int(W * 0.09)
    footer = int(W * 0.06) * max(1, len(spec.get("smalls") or []))
    canvas = Image.new("RGB", (W, H + top_pad + footer + crops_h), "white")
    canvas.paste(im, (0, top_pad))
    dr = ImageDraw.Draw(canvas)

    for i, sm in enumerate(spec.get("smalls") or []):
        x1, y1, x2, y2 = sm["box"]
        bx1, by1 = x1 * W, top_pad + y1 * H
        bx2, by2 = x2 * W, top_pad + y2 * H
        dr.rectangle([bx1, by1, bx2, by2], outline=RED, width=max(2, int(W * 0.006)))

        txt = sm["text"]
        lw = dr.textlength(txt, font=f)
        lx = max(2, min(bx1, W - lw - 4))
        ly = top_pad - max(24, int(W * 0.05))
        dr.rectangle([lx - 3, ly - 2, lx + lw + 3, ly + int(W * 0.045)], fill=YELLOW)
        dr.text((lx, ly), txt, font=f, fill=(0, 0, 0))
        arrow(dr, (lx + lw / 2, ly + int(W * 0.045) + 4), ((bx1 + bx2) / 2, by1))

        # 编号清单，便于和 spec 对照
        dr.text((2, top_pad + H + 4 + i * int(W * 0.06)),
                "%d. %s  box=[%.3f, %.3f, %.3f, %.3f]" % (i + 1, txt, x1, y1, x2, y2),
                font=fsmall, fill=(80, 80, 80))

    # 证据条：框内内容放大后逐一列出，框里是不是那行字一眼可见
    if cells:
        y0 = top_pad + H + footer + 12
        dr.text((2, y0), "框内实际内容", font=fsmall, fill=(80, 80, 80))
        y0 += 22
        for txt, c in cells:
            dr.rectangle([2, y0, 2 + c.width + 2, y0 + c.height + 2], outline=(120, 120, 120))
            canvas.paste(c, (3, y0 + 1))
            dr.text((8 + c.width, y0 + 4), "<- %s" % txt, font=f, fill=RED)
            y0 += c.height + 34

    canvas.save(out_path)
    return canvas.size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--only", default=None, help="只处理 out 文件名包含该关键字的条目")
    a = ap.parse_args()
    specs = json.load(open(a.spec, encoding="utf-8-sig"))
    if isinstance(specs, dict):
        specs = [specs]
    base = os.path.dirname(os.path.abspath(a.spec))
    outdir = a.outdir or base
    os.makedirs(outdir, exist_ok=True)
    for s in specs:
        if a.only and a.only not in s.get("out", ""):
            continue
        if not os.path.isabs(s["label"]):
            s["label"] = os.path.join(base, s["label"])
        name = os.path.splitext(os.path.basename(s.get("out") or s["label"]))[0] + "_anchor.png"
        print("PREVIEW", name, preview(s, os.path.join(outdir, name)))


if __name__ == "__main__":
    main()
