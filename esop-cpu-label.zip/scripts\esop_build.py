﻿# -*- coding: utf-8 -*-
"""
ESOP CPU 标签核对图生成器

把 CPU 标签原图做成产线 ESOP 用的放大核对图：
标签原图 + 红色放大等级数字 + 红框圈小字版本 + 绿色指示箭头 + 底部联想PN/供应商PN

用法:
    python esop_build.py spec.json [--outdir 输出目录]

spec.json 是一个数组，每个元素:
{
  "label": "标签图路径",              # 必填，相对 spec 所在目录或绝对路径
  "big": "9",                        # 性能等级数字，可空
  "smalls": [                        # 小字版本标注，可空、可多个
     {"text": "ENT", "box": [x1,y1,x2,y2], "pos": "left|right|top"},
     {"text": "3",  "box": [...], "pos": "top"}
  ],
  "pn": {"lenovo": "SL11R20980", "supplier": "360644-001"},
  "out": "01_xxx.png"
}
box 是标签图上的相对坐标（0~1，左上角为原点），框住标签上那行小字的实际位置。
"""
import os, sys, json, math, argparse
from PIL import Image, ImageDraw, ImageFont, ImageFilter

RED = (255, 0, 0)
GREEN = (0, 176, 80)
WHITE = (255, 255, 255)

PAD_TOP = 50
LEFT_ZONE_W = 340
RIGHT_ZONE_W = 360
LABEL_MAX_W, LABEL_MAX_H = 560, 620
GAP = 60
TOP_PAD = 210


def _font_path():
    cands = [
        r"C:\Windows\Fonts\msyhbd.ttc",
        r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/System/Library/Fonts/PingFang.ttc",
    ]
    for c in cands:
        if os.path.exists(c):
            return c
    raise RuntimeError("找不到可用中文字体，请安装微软雅黑或 Noto Sans CJK")


FPATH = _font_path()


def F(size):
    return ImageFont.truetype(FPATH, size, index=0)


def bbox(dr, txt, f):
    b = dr.textbbox((0, 0), txt, font=f)
    return b[2] - b[0], b[3] - b[1], b


def put(dr, x, y, txt, f, fill):
    """以字形左上角为原点绘制，返回真实占用框"""
    b = dr.textbbox((0, 0), txt, font=f)
    dr.text((x - b[0], y - b[1]), txt, font=f, fill=fill)
    return (x, y, x + (b[2] - b[0]), y + (b[3] - b[1]))


def fit(dr, txt, max_w, start, floor=26):
    s = start
    while s > floor:
        f = F(s)
        if bbox(dr, txt, f)[0] <= max_w:
            return f, bbox(dr, txt, f)[0]
        s -= 2
    f = F(floor)
    return f, bbox(dr, txt, f)[0]


def arrow(dr, start, end, width=12, head=34):
    dx, dy = end[0] - start[0], end[1] - start[1]
    L = math.hypot(dx, dy)
    if L < 2:
        return
    ux, uy = dx / L, dy / L
    base = (end[0] - ux * head, end[1] - uy * head)
    dr.line([start, base], fill=GREEN, width=width)
    px, py = -uy, ux
    hw = head * 0.45
    dr.polygon([end, (base[0] + px * hw, base[1] + py * hw), (base[0] - px * hw, base[1] - py * hw)], fill=GREEN)


def render(spec, out_path):
    im = Image.open(spec["label"]).convert("RGB")
    ratio = min(LABEL_MAX_W / im.width, LABEL_MAX_H / im.height)
    nw, nh = int(im.width * ratio), int(im.height * ratio)
    im = im.resize((nw, nh), Image.LANCZOS)
    if ratio > 1.5:
        im = im.filter(ImageFilter.UnsharpMask(radius=1.0, percent=55))

    smalls = spec.get("smalls") or []
    has_top = any(s.get("pos") == "top" for s in smalls)
    pad_top = TOP_PAD if has_top else PAD_TOP
    lx, ly = LEFT_ZONE_W, pad_top
    rzone_x = lx + nw + GAP

    canvas_w = rzone_x + RIGHT_ZONE_W + 80
    canvas_h = ly + nh + (310 if not spec.get("note") else 380)
    canvas = Image.new("RGB", (canvas_w, canvas_h), WHITE)
    dr = ImageDraw.Draw(canvas)
    canvas.paste(im, (lx, ly))

    # 大等级数字
    num_box = None
    big_txt = spec.get("big") or ""
    if big_txt:
        f, _ = fit(dr, big_txt, RIGHT_ZONE_W - 24, max(90, int(nw * 0.30)))
        num_box = put(dr, rzone_x, ly + 8, big_txt, f, RED)

    # 小字版本标注
    left_cur = ly + 10
    right_cur = (num_box[3] + GAP) if num_box else ly + 10
    for sm in smalls:
        txt = sm["text"]
        x1, y1, x2, y2 = sm["box"]
        ix1, iy1 = lx + x1 * nw, ly + y1 * nh
        ix2, iy2 = lx + x2 * nw, ly + y2 * nh
        cx = (ix1 + ix2) / 2

        side = sm.get("pos") or ("left" if cx < lx + nw * 0.36 else "right")
        zone_w = (LEFT_ZONE_W - 40) if side == "left" else (RIGHT_ZONE_W - 40)
        f, tw = fit(dr, txt, zone_w - 40, 96)
        th = bbox(dr, txt, f)[1]
        bx_pad, by_pad = 20, 14
        bw, bh = tw + bx_pad * 2, th + by_pad * 2

        if side == "top":
            bx = max(10, min(int(cx - bw / 2), canvas_w - bw - 10))
            by = 20
        elif side == "left":
            bx = max(16, LEFT_ZONE_W - 30 - bw)
            by = left_cur
            left_cur = by + bh + 40
        else:
            bx = rzone_x
            by = right_cur
            right_cur = by + bh + 40

        dr.rectangle([bx, by, bx + bw, by + bh], outline=RED, width=9)
        put(dr, bx + bx_pad, by + by_pad, txt, f, RED)

        # 标签内对应位置红框
        e = 6
        dr.rectangle([ix1 - e, iy1 - e, ix2 + e, iy2 + e], outline=RED, width=9)

        if side == "top":
            arrow(dr, (bx + bw / 2, by + bh + 2), (cx, iy1))
        elif side == "left":
            arrow(dr, (bx + bw + 2, by + bh / 2), (cx, (iy1 + iy2) / 2))
        else:
            arrow(dr, (bx - 2, by + bh / 2), (cx, (iy1 + iy2) / 2))

    # 底部双 PN（固定）
    pn = spec.get("pn") or {}
    y = ly + nh + 56
    if pn.get("lenovo"):
        f, _ = fit(dr, pn["lenovo"], canvas_w - lx - 60, max(60, int(nw * 0.17)), 40)
        b = put(dr, lx + 6, y, pn["lenovo"], f, RED)
        y = b[3] + 22
    if pn.get("supplier"):
        txt = "供应商PN:" + pn["supplier"]
        f, _ = fit(dr, txt, canvas_w - lx - 60, max(34, int(nw * 0.088)), 26)
        b = put(dr, lx + 6, y, txt, f, RED)
        y = b[3] + 18

    # 脚注（可选），用于补充说明，如"丝印区以实物为准"
    if spec.get("note"):
        f, _ = fit(dr, spec["note"], canvas_w - lx - 60, 30, 18)
        put(dr, lx + 6, y, spec["note"], f, (70, 70, 70))

    # 裁白边
    g = canvas.convert("L").point(lambda v: 0 if v < 250 else 255)
    content = Image.eval(g, lambda v: 255 - v).getbbox()
    m = 36
    box = (max(0, content[0] - m), max(0, content[1] - m),
           min(canvas.width, content[2] + m), min(canvas.height, content[3] + m))
    out = canvas.crop(box)
    out.save(out_path)
    return out.size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("--outdir", default=None)
    a = ap.parse_args()
    specs = json.load(open(a.spec, encoding="utf-8-sig"))
    if isinstance(specs, dict):
        specs = [specs]
    base = os.path.dirname(os.path.abspath(a.spec))
    outdir = a.outdir or base
    os.makedirs(outdir, exist_ok=True)
    for s in specs:
        if not os.path.isabs(s["label"]):
            s["label"] = os.path.join(base, s["label"])
        if not os.path.exists(s["label"]):
            print("MISSING LABEL:", s["label"])
            continue
        out = os.path.join(outdir, s["out"])
        print("OK", s["out"], render(s, out))


if __name__ == "__main__":
    main()
