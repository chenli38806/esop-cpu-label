# -*- coding: utf-8 -*-
"""
锚点测量辅助：把标签图放大并叠加 10%/5% 网格，用来目测 smalls.box 的百分比坐标。

用法:
    python measure_grid.py 标签.png [--width 760] [-o out.png]
输出图上每 10% 标数字刻度，每 5% 画细线。读图后按刻度写 box=[x1,y1,x2,y2]。
"""
import os, argparse
from PIL import Image, ImageDraw


def build(src, out, W=760):
    im = Image.open(src).convert("RGB")
    im = im.resize((W, int(im.height * W / im.width)), Image.LANCZOS)
    h = im.height
    canvas = Image.new("RGB", (W + 90, h + 40), "white")
    dr = ImageDraw.Draw(canvas)
    canvas.paste(im, (60, 20))
    for k in range(1, 20):
        yy = 20 + int(h * k / 20)
        xx = 60 + int(W * k / 20)
        col = (0, 160, 0) if k % 2 == 0 else (150, 220, 150)
        dr.line([(60, yy), (60 + W, yy)], fill=col)
        dr.line([(xx, 20), (xx, 20 + h)], fill=col)
    for k in range(0, 11):
        dr.text((10, 20 + int(h * k / 10) - 6), f"{k*10}", fill=(0, 90, 0))
        dr.text((60 + int(W * k / 10) - 6, 2), f"{k*10}", fill=(0, 90, 0))
    dr.rectangle([60, 20, 60 + W, 20 + h], outline=(0, 0, 0))
    canvas.save(out)
    print(out, canvas.size)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("image")
    ap.add_argument("--width", type=int, default=760)
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()
    out = a.out or os.path.splitext(a.image)[0] + "_grid.png"
    build(a.image, out, a.width)
