# CPU 标签标注规则

来源：LSSC IDG OOB/XCSA 问题通报（CPU 标签用错）附件《CPU 标签维护模板参考》xlsx + pptx，已完成现场验证，产线统一按此维护。

## 一、标注规则表（xlsx「图表配色标准参考」原表）

| 序号 | 类别 | 参考要求 |
| --- | --- | --- |
| 1 | 性能核心数（i5 / i7 / 5 / 7 / 9） | 微软雅黑，80，加粗，标准色红色 |
| 2 | 小字版本（一般只标注前三位） | 1. 字体微软雅黑，50，加粗，标准色红色；2. 红框形状轮廓，标准色红色，宽度 5 磅 |
| 3 | 指示箭头 | 单向箭头，实线，标准色绿色，宽度 10 磅 |
| 4 | 红框框（一般圈小字或特殊提示） | 标准色红框，实线，宽度 5 磅 |
| 5 | 联想 PN | 微软雅黑，50，加粗，标准色红色 |
| 6 | 供应商 PN | 微软雅黑，25，加粗，标准色红色 |

配套文字要求（原邮件）：
1. 突出标识 5/7/9 此类性能等级编号（Ultra / vPRO 等大字不再放大突出，方便标签画面简洁清晰，产线照常核对信息）。
2. 突出标识附加的小字版本或 AI 等特殊提示。
3. 图片底部固定增加联想 PN + 供应商 PN。

## 二、小字版本对照词典

| 标签上的文字 | 标注用缩写 | 含义 |
| --- | --- | --- |
| AMD Ryzen AI | AI | AMD 的 AI 加速标识 |
| Radeon Graphics | GRA | 核显型号 |
| Enterprise（vPro Enterprise） | ENT | vPro 企业版 |
| Essentials（vPro Essentials） | Ess | vPro 基础版 |
| Copilot+PC | Cop | 微软 Copilot+ PC 认证 |
| An Evo Design | An EVO | Evo 设计认证 |
| EVO Edition | EVO | Evo 版本 |
| Series 3 | 3 | 处理器世代号（在标签顶部） |
| 7000 / 6000 SERIES | 7000 / 6000 | 平台世代（Ryzen，在标签底部条） |
| ATHLON GOLD | GOLD | Athlon 金标 |
| 丝印 | 丝印 | 标签上的丝印编号区 |

### 世代号定位（曾出错的点）

AMD Ryzen 标签的 `7000 / 6000` **只印在底部灰条的 "XXXX SERIES" 里**，AMD RYZEN 大字区写的是品牌名，没有世代号。红框必须框住底部条上那几个数字：

| 标签 | box 参考值 | 说明 |
| --- | --- | --- |
| RYZEN 7000 SERIES | `[0.142, 0.772, 0.322, 0.898]` | 框住 "7000"，右边界到 SERIES 前止 |
| RYZEN 6000 SERIES | `[0.075, 0.775, 0.320, 0.910]` | 起点 0.075 才能含住首位数字，别从 0.15 起 |

判定方法：先用 `measure_grid.py` 看网格图，确认数字的确切位置；框写完再跑 `preview_anchor.py` 复核。**不要按型号名在 AMD RYZEN 大字上找数字。**

## 三、版式常量（脚本内已固化，需改时同步 `scripts/esop_build.py`）

| 常量 | 值 | 含义 |
| --- | --- | --- |
| LABEL_MAX_W / H | 560 / 620 px | 标签本体最大缩放尺寸 |
| 等级数字字号 | 标签宽度 30%（下限 90px） | 自动 fit，长文本自动缩字号 |
| 小字字号 | 上限 96px，超出区宽自动缩小 | 标注块内边距 20/14 px |
| 红框线宽 | 9 px | 约等于 5 磅在输出分辨率下的观感 |
| 箭头 | 线宽 12 px，箭头长 34 px | 绿色 #00B050 |
| 联想 PN | 标签宽度 17%（下限 60px） | 红色 |
| 供应商 PN | 标签宽度 8.8%（下限 34px） | 红色，前缀「供应商PN:」 |
| GAP | 60 px | 标签与右侧标注区间距 |

## 四、已验证案例（可作为取数参考）

| 文件 | 标签 | big | smalls | 联想 PN | 供应商 PN |
| --- | --- | --- | --- | --- | --- |
| 01_intel_ultra9_ENT | intel core ULTRA 9 / vPRO ENTERPRISE | 9 | ENT | SL11R20980 | 360644-001 |
| 02_intel_ultra5_EVO | intel core ULTRA 5 / vPRO EVO EDITION | 5 | EVO | SL11R20977 | 360639-001 |
| 03_intel_vpro_i5_AnEVO | intel vPRO / An Evo Design / i5 | i5 | An EVO | SL11H67268 | 348361-001 |
| 04_intel_vpro_i5_Ess | intel vPRO / Essentials / i5 | i5 | Ess | SL11H67262 | 348352-001 |
| 05_intel_core_ultra9 | intel core ULTRA 9 | 9 | — | SL11N34252 | 355516-001 |
| 06_intel_series3_X9_EVO | Series 3 / ULTRA X9 / vPRO EVO EDITION | X9 | 3(top), EVO | SL11V47611 | 367699-001 |
| 07_intel_series3_ultra9 | Series 3 / ULTRA 9 / vPRO | 9 | 3(top) | SL11V43109 | 367675-001 |
| 08_intel_series3_ultra9_Copilot | Series 3 / ULTRA 9 / Copilot+PC | 9 | 3(top), Cop | SL11V43106 | 367506-001 |
| 09_amd_ryzen_ai_pro9 | AMD RYZEN AI PRO 9 | 9 | AI | SL11U43954 | 3446300-A |
| 10_amd_ryzen9 | AMD RYZEN 9 | 9 | — | SL11P68481 | 2367952-A |
| 11_amd_ryzen_ai_pro9_HX | AMD RYZEN AI PRO 9 HX | 9 HX | AI | SL11Q62673 | 2682200-A |
| 12_amd_ryzen_ai_max | AMD RYZEN AI MAX | MAX | AI | SL11S13299 | 2730240-A |
| 13_amd_radeon_graphics | AMD RADEON GRAPHICS | — | GRA | SL11K68063 | 2340552-A |
| 14_amd_ryzen_7000_9 | AMD RYZEN / 7000 SERIES / 9 | 9 | 7000（底部 SERIES 条） | SL11K83399 | 1581614-A |
| 15_amd_athlon_gold | AMD ATHLON GOLD | — | GOLD | SL10Y57781 | 330266-A |
| 16_amd_ryzen_6000_9 | AMD RYZEN / 6000 SERIES / 9 | 9 | 6000（底部 SERIES 条）, 丝印（右边缘） | SL11H68103 | 991104-A |
| 17_amd_radeon_graphics_red | AMD RADEON GRAPHICS（红底） | — | GRA | SL11C41659 | 596989-A |

### 已验证的锚点参考值（17 张实测，可直接套用相似版式）

| 标签版式 | 标注 | box | 备注 |
| --- | --- | --- | --- |
| Intel Ultra 9 竖版 | ENT | `[0.44, 0.855, 0.965, 0.945]` | 底部 vPRO 说明条 |
| Intel vPRO i5 竖版 | An EVO | `[0.062, 0.838, 0.722, 0.926]` | 框全整行 "An Evo Design" |
| Intel vPRO i5 竖版 | Ess | `[0.095, 0.845, 0.712, 0.938]` | 框全 "Essentials" |
| Intel Series 3 | 3 | `[0.43, 0.07, 0.495, 0.19]` | 必须配 `pos: top` |
| AMD Ryzen 7000 | 7000 | `[0.142, 0.772, 0.322, 0.898]` | 底部条，**不是 RYZEN 大字** |
| AMD Ryzen 6000 | 6000 | `[0.075, 0.775, 0.320, 0.910]` | 底部条，起点要含首位数字 |
| AMD Ryzen 6000 | 丝印 | `[0.855, 0.075, 0.992, 0.340]` | 右边缘偏上，配 note 说明 |

## 五、ESOP 摆放要求（现场展示）

- 任意两个标签之间上下左右间距 5 mm。
- 标签图在 ESOP 页面中按统一版式并排，不旋转、不拉伸。
