# -*- coding: utf-8 -*-
"""
spec 静态校验：在渲染前把能机器判定的错误全部揪出来。

跑法:
    python validate.py spec.json

检查项:
  [ERROR] box 越界 / 顺序颠倒 / 退化
  [ERROR] 框内几乎没有笔划（框中空白，说明锚点没落在字上）
  [ERROR] 缺联想 PN 或供应商 PN、PN 明显不合格式
  [ERROR] out 文件名重复
  [WARN ] 框过大（囊括整块区域）或过小（框不住字）
  [WARN ] 同一条 spec 内两个框大面积重叠
  [WARN ] 标注文本不在已知词典里
有 ERROR 时退出码为 1，可直接用于批处理拦截。
"""
import os, sys, re, json, argparse
from PIL import Image

DICT = {"ENT", "EVO", "AN EVO", "ESS", "COP", "AI", "GRA", "GOLD", "丝印",
        "3", "7000", "6000", "5000", "8000", "9000"}


def stroke_ratio(img, box):
    """框内与背景差异明显的像素占比，近似'有没有字'"""
    w, h = img.size
    x1, y1, x2, y2 = box
    crop = img.crop((int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h))).convert("L")
    if crop.width < 3 or crop.height < 3:
        return 0.0
    hist = crop.histogram()
    n = sum(hist)
    cum = 0
    med = 0
    for i, c in enumerate(hist):
        cum += c
        if cum >= n / 2:
            med = i
            break
    hit = sum(c for i, c in enumerate(hist) if abs(i - med) > 40)
    return hit / n


def check_image(spec, label_path):
    errs, warns = [], []
    smalls = spec.get("smalls") or []
    if not smalls:
        warns.append("没有 smalls，只有等级数字")
    try:
        img = Image.open(label_path)
    except Exception as e:
        errs.append("标签图打不开: %s" % e)
        return errs, warns

    for sm in smalls:
        txt = sm.get("text", "?")
        box = sm.get("box")
        if not box or len(box) != 4:
            errs.append("[%s] box 缺失或不是 4 个数" % txt)
            continue
        x1, y1, x2, y2 = box
        if not (0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1):
            errs.append("[%s] box 越界或顺序颠倒 %s" % (txt, box))
            continue
        bw, bh = x2 - x1, y2 - y1
        if bw < 0.03 or bh < 0.03:
            warns.append("[%s] 框过小 %.3f×%.3f，可能框不住字" % (txt, bw, bh))
        if bw > 0.55 or bh > 0.35:
            warns.append("[%s] 框过大 %.3f×%.3f，可能囊括整块区域" % (txt, bw, bh))

        ratio = stroke_ratio(img, box)
        if ratio < 0.02:
            errs.append("[%s] 框内笔划占比仅 %.1f%%，框里基本是空白——锚点没落在字上" % (txt, ratio * 100))

        if txt.upper() not in DICT:
            warns.append("[%s] 不在已知标注词典里，确认是否需要新增" % txt)

    # 框之间重叠
    for i in range(len(smalls)):
        for j in range(i + 1, len(smalls)):
            a, b = smalls[i].get("box"), smalls[j].get("box")
            if not a or not b:
                continue
            ox = min(a[2], b[2]) - max(a[0], b[0])
            oy = min(a[3], b[3]) - max(a[1], b[1])
            if ox > 0 and oy > 0:
                area_a = (a[2] - a[0]) * (a[3] - a[1])
                if ox * oy / area_a > 0.3:
                    warns.append("[%s] 与 [%s] 重叠过多" % (smalls[i].get("text"), smalls[j].get("text")))
    return errs, warns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    a = ap.parse_args()
    specs = json.load(open(a.spec, encoding="utf-8-sig"))
    if isinstance(specs, dict):
        specs = [specs]
    base = os.path.dirname(os.path.abspath(a.spec))

    total_e = total_w = 0
    tpl = 0
    outs = []
    for s in specs:
        name = s.get("out") or os.path.basename(s.get("label", "?"))
        outs.append(name)
        errs, warns = [], []
        pn = s.get("pn") or {}
        if not pn.get("lenovo"):
            errs.append("缺联想 PN")
        elif len(str(pn["lenovo"])) < 5 or " " in str(pn["lenovo"]):
            errs.append("联想 PN 格式可疑: %r" % pn["lenovo"])
        if not pn.get("supplier"):
            errs.append("缺供应商 PN")
        elif "-" not in str(pn["supplier"]):
            warns.append("供应商 PN 通常形如 360644-001，请核对: %r" % pn["supplier"])
        if s.get("big") and not re.match(r"^[A-Za-z0-9 ]{1,8}$", str(s["big"])):
            warns.append("big 含非字母数字字符: %r" % s["big"])

        label = s["label"]
        if not os.path.isabs(label):
            label = os.path.join(base, label)
        if os.path.basename(label).startswith("YOUR_"):
            # 模板占位路径，跳过图检查，只校验参数本身
            tpl += 1
        elif not os.path.exists(label):
            errs.append("标签图不存在: %s" % label)
        else:
            e2, w2 = check_image(s, label)
            errs += e2
            warns += w2

        if errs or warns:
            print("== %s" % name)
            for e in errs:
                print("  ERROR  %s" % e)
            for w in warns:
                print("  WARN   %s" % w)
        total_e += len(errs)
        total_w += len(warns)

    dup = {o for o in outs if outs.count(o) > 1}
    if dup:
        print("== 全局")
        for d in dup:
            print("  ERROR  out 文件名重复: %s" % d)
        total_e += len(dup)

    print("\n汇总: %d 条 spec, %d 个 ERROR, %d 个 WARN" % (len(specs), total_e, total_w))
    if tpl:
        print("提示: 其中 %d 条的 label 是占位路径 YOUR_*，使用前替换成真实标签图" % tpl)
    sys.exit(1 if total_e else 0)


if __name__ == "__main__":
    main()
